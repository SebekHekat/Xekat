document.addEventListener("DOMContentLoaded", () => {
  const root = document.getElementById("root");
  const now = new Date();
  const pad = (n) => (n < 10 ? '0' + n : n);
  const formatTime = () => pad(now.getHours()) + ':' + pad(now.getMinutes()) + ':' + pad(now.getSeconds());

  root.innerHTML = `
    <h1>XEKAT — From Creator to Creator</h1>
    <p>Введите дату и время рождения:</p>
    <input type="date" id="dateInput" /><br/>
    <input type="time" id="timeInput" /><br/>
    <button id="runBtn">Рассчитать</button>
    <p id="output"></p>
    <button id="momentBtn">📍 Зафиксировать момент</button>
    <p id="momentOut"></p>
  `;

  document.getElementById("runBtn").onclick = () => {
    const dateVal = document.getElementById("dateInput").value;
    const timeVal = document.getElementById("timeInput").value;

    if (!dateVal || !timeVal) return;

    const [y, m, d] = dateVal.split("-").map(Number);
    const [h, min, s] = timeVal.split(":").map(Number);
    const total = (y + m + d + h + min + s) % 37;
    const result = [
      "🔑 Основное число (врата): " + total,
      "🕐 Часовое число: " + (h % 37),
      "🕑 Минутное число: " + (min % 37),
      "🕒 Секундное число: " + (s % 37),
      "🔢 Сумма всех цифр: " + ('' + y + m + d + h + min + s).split('').map(Number).reduce((a,b) => a+b, 0)
    ].join("<br/>");

    document.getElementById("output").innerHTML = result;
  };

  document.getElementById("momentBtn").onclick = () => {
    const current = new Date();
    const h = current.getHours();
    const m = current.getMinutes();
    const s = current.getSeconds();
    const total = (h + m + s) % 37;
    document.getElementById("momentOut").innerHTML = 
      `Момент: ${formatTime()}<br/>🎯 Число момента: ${total}`;
  };
});
